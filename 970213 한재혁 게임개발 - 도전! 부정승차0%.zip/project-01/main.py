""" pygame project 연습 1 """
" 패키지 import "
import sys
from random import randint, choice

import pygame
from pygame.locals import *

" pygame 초기화 및 화면 설정 "
pygame.init()
Surface = pygame.display.set_mode((1200, 800))
pygame.display.set_caption("도전! 부정승차 0%")
pygame.key.set_repeat(5, 5)
FPSCLOCK = pygame.time.Clock()

" 음악 재생 "
pygame.mixer.init()
pygame.mixer.music.load("music/Sunny Travel - Nico Staf.mp3")
pygame.mixer.music.play(-1)

" 이미지 input "
Background = pygame.image.load("images/게임 진행배경.png")
Background = pygame.transform.scale(Background, (1200, 800))

police = pygame.image.load("images/police.png")
police = pygame.transform.scale(police, (100, 100))

" 사람 이미지를 리스트로 정리 "
person_image = ["images/01.png", "images/02.png", "images/03.png", "images/04.png", "images/05.png",
                "images/06.png", "images/07.png", "images/08.png", "images/09.png", "images/10.png",
                "images/11.png", "images/12.png", "images/13.png", "images/14.png"]

" 사람이 리스트에서 랜덤하게 등장 "
person = pygame.image.load(choice(person_image))
person = pygame.transform.scale(person, (120, 140))

" 경찰이 나타날 좌표 지정 "
policeX, policeY = 900, 400

" 기타 문구 설정 및 값 세팅"
GAME = False # 초기화면에서 시작
NEXT_STAGE = True
# page = False # 초기화면에서 시작
velocity = randint(3, 6) # 랜덤한 속도 input
score = 0
stage = 1
page = 1
missed_person = 0
font = pygame.font.SysFont("바른돋움OTFPro 3", 36)

" 버튼 함수 정의 "
def button_first(): # 초기화면 버튼
    global GAME, stage, page
    if event.type == MOUSEBUTTONUP:
        if 400 <= pygame.mouse.get_pos()[0] <= 800:
            if 400 <= pygame.mouse.get_pos()[1] <= 540:
                GAME = True # 게임 시작
            elif 600 <= pygame.mouse.get_pos()[1] <= 740:
                page = 2 # 게임방법 화면으로

def button_second(): # 게임방법화면 버튼
    global stage, page
    if event.type == MOUSEBUTTONUP:
        if 1005 <= pygame.mouse.get_pos()[0] <= 1170:
            if 725 <= pygame.mouse.get_pos()[1] <= 775:
                page = 1 # 게임 초기화면으로
                stage = 1

def button_third(): # 게임클리어화면 버튼
    global GAME, stage, page
    if event.type == MOUSEBUTTONUP:
        if 45 <= pygame.mouse.get_pos()[0] <= 260:
            if 490 <= pygame.mouse.get_pos()[1] <= 540:
                GAME = False
                page = 1 # 게임 초기화면으로

        if 960 <= pygame.mouse.get_pos()[0] <= 1165:
            if 490 <= pygame.mouse.get_pos()[1] <= 550:
                pygame.quit() # 게임 종료
                sys.exit()

class PERSON: # 사람 이미지 클래스

    def __init__(self, x, y, type, image):
        self.x = x
        self.y = y
        self.live = True
        self.type = type
        self.image = image

    def move(self):
        global score
        global missed_person
        global person
        global GAME

        self.x += velocity

        if self.live:
            rect_person = person.get_rect()
            rect_person.center = (self.x, self.y)
            Surface.blit(self.image, rect_person)

            if self.x >= 550 and self.type == 1 and self.live:
                pygame.draw.circle(Surface, (255, 0, 0), (self.x, self.y - 80), 10, 4)

            if rect_police.colliderect(rect_person) and event.type == KEYDOWN and self.live: # 경찰과 사람이 부딪히고
                if event.key == K_SPACE: # 스페이스바가 눌리면
                    self.live = False
                    if self.type != 1: # 만약 사람의 type이 1이 아니라면
                        score += 1
                    else: # 만약 사람이 type이 1이라면
                        missed_person += 1

            elif self.x >= Surface.get_width() and self.live: # 사람이 화면 오른쪽 끝까지 이동하면
                self.live = False # 사람을 없애고
                if self.type == 1: # 만약 사람의 type이 1이라면
                    score += 1
                else: # 만약 사람의 type이 2라면
                    missed_person += 1


while True:
    if NEXT_STAGE and GAME: # 다음 스테이지로 넘어가면서 사람 다시 생성
        NEXT_STAGE = False
        Persons = []
        for i in range(15 * stage):
            x = randint(-4000, 10)
            y = randint(150, 750)
            type = choice([1, 2])
            image = pygame.image.load(choice(person_image))
            image = pygame.transform.scale(image, (120, 140))
            Persons.append(PERSON(x, y, type, image))

    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()

        elif event.type == KEYDOWN:
            if event.key == K_UP and policeY >= 40:
                policeY -= 5
            elif event.key == K_DOWN and policeY <= Surface.get_height() - 40:
                policeY += 5
            elif event.key == K_RIGHT and policeX <= Surface.get_width() - 30:
                policeX += 5
            elif event.key == K_LEFT and policeX >= 750:
                policeX -= 5
            elif event.key == K_ESCAPE: # 음악 종료
                pygame.mixer.music.stop()
            elif event.key == K_LCTRL: # 음악 재생
                pygame.mixer.music.play(-1)

    if not GAME and page == 1:  # 게임 초기화면
        start_image = pygame.image.load("images/게임 시작배경.jpg")
        start_image = pygame.transform.scale(start_image, (1200, 800))
        title_image = pygame.image.load("images/표지.png")
        title_image = pygame.transform.scale(title_image, (1120, 140))
        start_button = pygame.image.load("images/게임시작.png")
        start_button = pygame.transform.scale(start_button, (400, 140))
        how_to = pygame.image.load("images/게임방법.png")
        how_to = pygame.transform.scale(how_to, (400, 140))

        Surface.blit(start_image, (0, 0))
        Surface.blit(title_image, (40, 80))
        Surface.blit(start_button, (400, 400))
        Surface.blit(how_to, (400, 600))

        button_first()

    elif GAME and stage < 4:  # 게임오버가 안되고 스테이지가 1~3이라면 : 게임 진행중

        Surface.blit(Background, (0, 0))  # 게임 진행 배경 지정
        " 경찰 위치 "
        rect_police = police.get_rect()
        rect_police.center = (policeX, policeY)
        Surface.blit(police, rect_police)

        " 사람 위치 "
        for i in range(15 * stage):
            Persons[i].move()

        " 정보 표시 "
        score_image = font.render("SCORE : {}".format(score), True, (128, 64, 0))
        stage_image = font.render("STAGE {}".format(stage), True, (128, 64, 0))
        miss_image = font.render("MISS : {}".format(missed_person), True, (128, 64, 0))
        Surface.blit(score_image, (850, 60))
        Surface.blit(stage_image, (850, 30))
        Surface.blit(miss_image, (850, 90))

        " stage 구분 "
        if score >= 10 * stage:
            score = 0
            stage += 1
            NEXT_STAGE = True
            if stage == 4:
                GAME = False
                page = 3
        if missed_person >= 5 * stage:
            GAME = False
            policeX, policeY = 900, 400
            score = 0
            missed_person = 0
            stage = 1
            NEXT_STAGE = True

    elif page == 3: # 3번째 스테이지까지 클리어하면 : 게임 클리어
        GAME = False
        policeX, policeY = 900, 400
        NEXT_STAGE = True
        stage = 1
        clear_image = pygame.image.load("images/게임 클리어배경.png")
        clear_image = pygame.transform.scale(clear_image, (1200, 800))
        Surface.blit(clear_image, (0, 0))

        button_third()

    if page == 2: # 게임 방법 설명화면
        Surface.fill((242, 113, 15))
        how_to_play = pygame.image.load("images/방법.png")
        how_to_play = pygame.transform.scale(how_to_play, (1200, 800))
        Surface.blit(how_to_play, (0, 0))

        button_second()

    pygame.display.update()
    FPSCLOCK.tick(60)